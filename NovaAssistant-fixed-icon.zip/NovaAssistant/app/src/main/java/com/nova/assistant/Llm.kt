package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Подключение к ИИ: Anthropic (Claude) или любой OpenAI-совместимый сервис. */
object Llm {
    fun plan(ctx: Context, user: String): Brain.Plan {
        return parse(ask(ctx, system(ctx), user))
    }

    fun parse(reply: String): Brain.Plan {
        val a = reply.indexOf('{')
        val b = reply.lastIndexOf('}')
        if (a >= 0 && b > a) {
            try {
                val o = JSONObject(reply.substring(a, b + 1))
                val arr = o.optJSONArray("actions") ?: JSONArray()
                val list = ArrayList<JSONObject>()
                for (i in 0 until arr.length()) {
                    val x = arr.optJSONObject(i)
                    if (x != null) list.add(x)
                }
                return Brain.Plan(o.optString("say", ""), list)
            } catch (e: Exception) {
                // не JSON — покажем ответ как обычный текст
            }
        }
        return Brain.Plan(reply.trim(), emptyList())
    }

    private fun system(ctx: Context): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale("ru")).format(Date())
        val bound = Prefs.bound(ctx).joinToString(", ") {
            it.alias + (if (it.messenger) " (мессенджер)" else "")
        }
        val favs = Apps.favorites(ctx, 5).joinToString(", ") { it.label }
        return buildString {
            append("Ты — Нова, голосовой ассистент на телефоне Android. ")
            append("Отвечай ТОЛЬКО одним JSON-объектом, без markdown и без пояснений. ")
            append("Формат: {\"say\":\"короткий ответ по-русски, 1-2 предложения\",\"actions\":[...]}\n")
            append("Допустимые действия (type):\n")
            append("- {\"type\":\"open_app\",\"app\":\"название приложения\"}\n")
            append("- {\"type\":\"message\",\"app\":\"whatsapp|telegram|название привязанного приложения\",\"to\":\"имя контакта\",\"text\":\"текст\"}\n")
            append("- {\"type\":\"alarm\",\"hour\":0-23,\"minute\":0-59,\"label\":\"необязательно\"}\n")
            append("- {\"type\":\"timer\",\"seconds\":число}\n")
            append("- {\"type\":\"photo\",\"front\":false} (front=true для селфи)\n")
            append("- {\"type\":\"favorite\",\"app\":\"название\"} (запомнить как любимое)\n")
            append("Если действие не нужно (вопрос, разговор) — верни \"actions\":[] и ответь в say.\n")
            append("Имя контакта пиши в именительном падеже («маме» → «Мама»). ")
            append("Если мессенджер не назван — используй ").append(Prefs.defaultMessenger(ctx)).append(". ")
            append("Текст сообщения пиши от лица пользователя, не меняя смысла. ")
            append("Время будильника считай от текущего: сейчас ").append(now).append(".\n")
            if (bound.isNotEmpty()) append("Привязанные приложения: ").append(bound).append(".\n")
            if (favs.isNotEmpty()) append("Любимые приложения: ").append(favs).append(".\n")
        }
    }

    private fun ask(ctx: Context, sys: String, user: String): String {
        val base = Prefs.llmBase(ctx).trim().trimEnd('/')
        val key = Prefs.llmKey(ctx)
        val model = Prefs.llmModel(ctx)

        if (base.contains("anthropic.com")) {
            val url = when {
                base.endsWith("/messages") -> base
                base.endsWith("/v1") -> base + "/messages"
                else -> base + "/v1/messages"
            }
            val body = JSONObject()
                .put("model", model)
                .put("max_tokens", 600)
                .put("system", sys)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
            val res = post(url, mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString())
            val arr = JSONObject(res).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val blk = arr.getJSONObject(i)
                if (blk.optString("type") == "text") sb.append(blk.optString("text"))
            }
            return sb.toString()
        }

        val url = if (base.endsWith("/chat/completions")) base else base + "/chat/completions"
        val msgs = JSONArray()
            .put(JSONObject().put("role", "system").put("content", sys))
            .put(JSONObject().put("role", "user").put("content", user))
        val body = JSONObject().put("model", model).put("messages", msgs)
        val res = post(url, mapOf("Authorization" to ("Bearer " + key)), body.toString())
        return JSONObject(res).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP " + code + ": " + text.take(160))
        return text
    }
}
