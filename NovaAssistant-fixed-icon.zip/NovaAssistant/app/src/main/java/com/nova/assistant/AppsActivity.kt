package com.nova.assistant

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Список установленных приложений: привязать, дать имя, пометить мессенджером, закрепить. */
class AppsActivity : Activity() {

    private var all: List<Apps.App> = emptyList()
    private var shown: List<Apps.App> = emptyList()
    private val icons = HashMap<String, Drawable>()
    private lateinit var adapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        all = Apps.all(this)
        shown = all

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B0D17"))
        root.setPadding(Ui.dp(this, 16), Ui.dp(this, 36), Ui.dp(this, 16), 0)

        val title = TextView(this)
        title.text = "Приложения"
        title.setTextColor(Color.WHITE)
        title.textSize = 26f
        title.setTypeface(null, Typeface.BOLD)
        root.addView(title)

        val hint = TextView(this)
        hint.text = "Нажмите на приложение, чтобы привязать его: Нова будет открывать его по вашему имени, " +
            "а в мессенджеры ещё и писать сообщения. ★ — любимые, они появятся на виджете."
        hint.setTextColor(Ui.TEXT2)
        hint.textSize = 13f
        val hl = LinearLayout.LayoutParams(-1, -2)
        hl.topMargin = Ui.dp(this, 6)
        root.addView(hint, hl)

        val search = EditText(this)
        search.hint = "Поиск по приложениям"
        search.setHintTextColor(Ui.TEXT2)
        search.setTextColor(Color.WHITE)
        search.textSize = 15f
        search.setSingleLine(true)
        search.background = Ui.round(Color.parseColor("#1FFFFFFF"), Ui.dp(this, 14).toFloat())
        search.setPadding(Ui.dp(this, 16), Ui.dp(this, 11), Ui.dp(this, 16), Ui.dp(this, 11))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                applyFilter(s?.toString() ?: "")
            }
        })
        val sl = LinearLayout.LayoutParams(-1, -2)
        sl.topMargin = Ui.dp(this, 12)
        sl.bottomMargin = Ui.dp(this, 10)
        root.addView(search, sl)

        val list = ListView(this)
        adapter = Adapter()
        list.adapter = adapter
        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = Ui.dp(this, 8)
        list.setOnItemClickListener { _, _, pos, _ -> edit(shown[pos]) }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        Ui.rise(list, 80L)
    }

    private fun applyFilter(q: String) {
        val n = Text.norm(q)
        shown = if (n.isEmpty()) {
            all
        } else {
            all.filter { Text.norm(it.label).contains(n) || it.pkg.lowercase().contains(n) }
        }
        adapter.notifyDataSetChanged()
    }

    private fun makeRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10))
        row.background = Ui.round(Color.parseColor("#14FFFFFF"), Ui.dp(this, 16).toFloat())

        val icon = ImageView(this)
        row.addView(icon, LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t1 = TextView(this)
        t1.setTextColor(Color.WHITE)
        t1.textSize = 16f
        val t2 = TextView(this)
        t2.textSize = 12f
        col.addView(t1)
        col.addView(t2)
        val cl = LinearLayout.LayoutParams(0, -2, 1f)
        cl.leftMargin = Ui.dp(this, 12)
        row.addView(col, cl)

        val star = TextView(this)
        star.text = "★"
        star.setTextColor(Color.parseColor("#FFC107"))
        star.textSize = 20f
        row.addView(star)
        return row
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = shown.size

        override fun getItem(position: Int): Any = shown[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val ctx = this@AppsActivity
            val row = (convertView as? LinearLayout) ?: makeRow()
            val a = shown[position]
            val icon = row.getChildAt(0) as ImageView
            val col = row.getChildAt(1) as LinearLayout
            val star = row.getChildAt(2) as TextView
            (col.getChildAt(0) as TextView).text = a.label

            val b = Prefs.boundOf(ctx, a.pkg)
            val sub = col.getChildAt(1) as TextView
            if (b != null) {
                sub.text = "привязано как «" + b.alias + "»" + (if (b.messenger) " · мессенджер" else "")
                sub.setTextColor(Ui.CYAN)
            } else {
                sub.text = "не привязано"
                sub.setTextColor(Ui.TEXT2)
            }
            star.visibility = if (Prefs.pinned(ctx).contains(a.pkg)) View.VISIBLE else View.INVISIBLE

            var d = icons[a.pkg]
            if (d == null) {
                d = try {
                    packageManager.getApplicationIcon(a.pkg)
                } catch (e: Exception) {
                    null
                }
                if (d != null) icons[a.pkg] = d
            }
            icon.setImageDrawable(d)
            return row
        }
    }

    private fun edit(a: Apps.App) {
        val b = Prefs.boundOf(this, a.pkg)
        val pin = Prefs.pinned(this).contains(a.pkg)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(Ui.dp(this, 22), Ui.dp(this, 8), Ui.dp(this, 22), 0)
        val alias = EditText(this)
        alias.setText(b?.alias ?: a.label)
        alias.hint = "Как к нему обращаться голосом"
        box.addView(alias)
        val msg = CheckBox(this)
        msg.text = "Это мессенджер (можно писать сообщения)"
        msg.isChecked = b?.messenger ?: Apps.isMessengerPkg(a.pkg)
        box.addView(msg)

        val d = AlertDialog.Builder(this)
            .setTitle(a.label)
            .setView(box)
            .setPositiveButton("Привязать") { _, _ ->
                val name = alias.text.toString().trim().ifEmpty { a.label }
                Prefs.bind(this, a.pkg, name, msg.isChecked)
                adapter.notifyDataSetChanged()
            }
            .setNeutralButton(if (pin) "Убрать из любимых" else "★ В любимые") { _, _ ->
                Prefs.setPinned(this, a.pkg, !pin)
                AssistantWidget.refresh(this)
                adapter.notifyDataSetChanged()
            }
        if (b != null) {
            d.setNegativeButton("Отвязать") { _, _ ->
                Prefs.unbind(this, a.pkg)
                adapter.notifyDataSetChanged()
            }
        }
        d.show()
    }
}
