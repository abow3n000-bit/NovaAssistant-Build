package com.nova.assistant

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

object Prefs {
    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("enabled", v).apply() }

    fun orbEverywhere(c: Context): Boolean = sp(c).getBoolean("orb_all", false)
    fun setOrbEverywhere(c: Context, v: Boolean) { sp(c).edit().putBoolean("orb_all", v).apply() }

    fun speak(c: Context): Boolean = sp(c).getBoolean("tts", true)
    fun setSpeak(c: Context, v: Boolean) { sp(c).edit().putBoolean("tts", v).apply() }

    fun countryCode(c: Context): String = sp(c).getString("cc", "7") ?: "7"
    fun setCountryCode(c: Context, v: String) {
        val d = v.filter { it.isDigit() }
        sp(c).edit().putString("cc", if (d.isEmpty()) "7" else d).apply()
    }

    fun defaultMessenger(c: Context): String = sp(c).getString("msg_default", "whatsapp") ?: "whatsapp"
    fun setDefaultMessenger(c: Context, v: String) { sp(c).edit().putString("msg_default", v).apply() }

    fun llmBase(c: Context): String = sp(c).getString("llm_base", "") ?: ""
    fun llmKey(c: Context): String = sp(c).getString("llm_key", "") ?: ""
    fun llmModel(c: Context): String = sp(c).getString("llm_model", "") ?: ""
    fun setLlm(c: Context, base: String, key: String, model: String) {
        sp(c).edit().putString("llm_base", base.trim()).putString("llm_key", key.trim()).putString("llm_model", model.trim()).apply()
    }
    fun llmReady(c: Context): Boolean = llmBase(c).isNotEmpty() && llmKey(c).isNotEmpty() && llmModel(c).isNotEmpty()

    fun orbX(c: Context): Int = sp(c).getInt("orb_x", -1)
    fun orbY(c: Context): Int = sp(c).getInt("orb_y", -1)
    fun setOrbPos(c: Context, x: Int, y: Int) { sp(c).edit().putInt("orb_x", x).putInt("orb_y", y).apply() }

    private fun json(c: Context, key: String): JSONObject {
        return try { JSONObject(sp(c).getString(key, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
    }

    // ---- любимые приложения ----
    fun countUse(c: Context, pkg: String) {
        val o = json(c, "usage")
        o.put(pkg, o.optInt(pkg, 0) + 1)
        sp(c).edit().putString("usage", o.toString()).apply()
    }

    fun usageMap(c: Context): Map<String, Int> {
        val o = json(c, "usage")
        val out = HashMap<String, Int>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            out[k] = o.optInt(k, 0)
        }
        return out
    }

    fun pinned(c: Context): Set<String> = sp(c).getStringSet("pinned", emptySet()) ?: emptySet()

    fun setPinned(c: Context, pkg: String, on: Boolean) {
        val s = HashSet<String>(pinned(c))
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("pinned", s).apply()
    }

    // ---- привязанные приложения ----
    class Bound(val pkg: String, val alias: String, val messenger: Boolean)

    fun bound(c: Context): List<Bound> {
        val o = json(c, "bound")
        val out = ArrayList<Bound>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = o.optJSONObject(k) ?: continue
            out.add(Bound(k, v.optString("alias"), v.optBoolean("msg")))
        }
        return out
    }

    fun bind(c: Context, pkg: String, alias: String, messenger: Boolean) {
        val o = json(c, "bound")
        o.put(pkg, JSONObject().put("alias", alias).put("msg", messenger))
        sp(c).edit().putString("bound", o.toString()).apply()
    }

    fun unbind(c: Context, pkg: String) {
        val o = json(c, "bound")
        o.remove(pkg)
        sp(c).edit().putString("bound", o.toString()).apply()
    }

    fun boundOf(c: Context, pkg: String): Bound? = bound(c).firstOrNull { it.pkg == pkg }
}
