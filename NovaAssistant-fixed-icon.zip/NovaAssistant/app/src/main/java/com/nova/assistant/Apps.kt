package com.nova.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas

object Apps {
    class App(val pkg: String, val label: String)

    val WA: List<String> = listOf("com.whatsapp", "com.whatsapp.w4b")
    val TG: List<String> = listOf(
        "org.telegram.messenger", "org.telegram.messenger.web", "com.exteragram.messenger",
        "org.thunderdog.challegram", "tw.nekomimi.nekogram"
    )
    private val YT = listOf("com.google.android.youtube")
    private val CHROME = listOf("com.android.chrome", "com.mi.globalbrowser")
    private val IG = listOf("com.instagram.android")
    private val TT = listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill")
    private val VK = listOf("com.vkontakte.android")
    private val VIBER = listOf("com.viber.voip")
    private val MAPS = listOf("com.google.android.apps.maps")
    private val GMAIL = listOf("com.google.android.gm")
    private val SPOTIFY = listOf("com.spotify.music")
    private val DISCORD = listOf("com.discord")

    private val SPOKEN: Map<String, List<String>> = mapOf(
        "whatsapp" to WA, "ватсап" to WA, "ватсапп" to WA, "вацап" to WA, "вотсап" to WA, "вотсапп" to WA,
        "telegram" to TG, "телеграм" to TG, "телеграмм" to TG, "телега" to TG, "тг" to TG,
        "youtube" to YT, "ютуб" to YT, "ютьюб" to YT,
        "chrome" to CHROME, "хром" to CHROME, "браузер" to CHROME,
        "instagram" to IG, "инстаграм" to IG, "инста" to IG,
        "tiktok" to TT, "тикток" to TT,
        "вк" to VK, "вконтакте" to VK, "vk" to VK,
        "viber" to VIBER, "вайбер" to VIBER,
        "карты" to MAPS, "maps" to MAPS,
        "gmail" to GMAIL, "почта" to GMAIL,
        "spotify" to SPOTIFY, "спотифай" to SPOTIFY,
        "discord" to DISCORD, "дискорд" to DISCORD
    )

    fun isMessengerPkg(pkg: String): Boolean =
        WA.contains(pkg) || TG.contains(pkg) || VIBER.contains(pkg)

    fun all(ctx: Context): List<App> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<App>()
        val seen = HashSet<String>()
        for (ri in pm.queryIntentActivities(i, 0)) {
            val p = ri.activityInfo.packageName
            if (p == ctx.packageName || !seen.add(p)) continue
            out.add(App(p, ri.loadLabel(pm).toString()))
        }
        out.sortBy { it.label.lowercase() }
        return out
    }

    fun resolve(ctx: Context, query: String): App? {
        val q = Text.norm(query)
        if (q.isEmpty()) return null
        val apps = all(ctx)
        val byPkg = HashMap<String, App>()
        for (a in apps) byPkg[a.pkg] = a

        // 1) привязанные приложения (то, как пользователь сам их назвал)
        for (b in Prefs.bound(ctx)) {
            val al = Text.norm(b.alias)
            if (al.isNotEmpty() && (al == q || q.contains(al) || (q.length >= 3 && al.contains(q)))) {
                val a = byPkg[b.pkg]
                if (a != null) return a
            }
        }
        // 2) известные названия (ватсап, телеграм, ютуб …)
        val words = q.split(" ")
        for ((k, pkgs) in SPOKEN) {
            if (q == k || words.contains(k)) {
                for (p in pkgs) {
                    val a = byPkg[p]
                    if (a != null) return a
                }
            }
        }
        // 3) по названию на экране телефона
        for (a in apps) if (Text.norm(a.label) == q) return a
        var best: App? = null
        var bestScore = 0
        for (a in apps) {
            val s = Text.nameScore(q, a.label)
            if (s > bestScore) {
                bestScore = s
                best = a
            }
        }
        if (best != null) return best
        // 4) по имени пакета (для латиницы)
        val compact = q.replace(" ", "")
        if (compact.length >= 4) {
            for (a in apps) if (a.pkg.lowercase().contains(compact)) return a
        }
        return null
    }

    /** Любимые: сначала закреплённые, потом самые часто открываемые. */
    fun favorites(ctx: Context, n: Int): List<App> {
        val byPkg = HashMap<String, App>()
        for (a in all(ctx)) byPkg[a.pkg] = a
        val use = Prefs.usageMap(ctx)
        val pinned = Prefs.pinned(ctx)
        val order = ArrayList<String>()
        order.addAll(pinned.sortedByDescending { use[it] ?: 0 })
        order.addAll(use.keys.filter { !pinned.contains(it) }.sortedByDescending { use[it] ?: 0 })
        val out = ArrayList<App>()
        for (p in order) {
            val a = byPkg[p] ?: continue
            out.add(a)
            if (out.size >= n) break
        }
        return out
    }

    fun icon(ctx: Context, pkg: String, px: Int): Bitmap? {
        return try {
            val d = ctx.packageManager.getApplicationIcon(pkg)
            val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            d.setBounds(0, 0, px, px)
            d.draw(c)
            b
        } catch (e: Exception) {
            null
        }
    }
}
