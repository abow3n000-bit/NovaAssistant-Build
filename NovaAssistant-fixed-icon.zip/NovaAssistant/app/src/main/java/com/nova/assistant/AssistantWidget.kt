package com.nova.assistant

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

/** Виджет на рабочий стол: шар Новы + до 4 любимых приложений. */
class AssistantWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    companion object {
        fun refresh(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, AssistantWidget::class.java))
                for (id in ids) mgr.updateAppWidget(id, build(ctx))
            } catch (e: Exception) {
                // виджета на экране может не быть — это нормально
            }
        }

        private fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget)
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            val talk = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, VoiceActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                flags
            )
            v.setOnClickPendingIntent(R.id.root, talk)
            v.setOnClickPendingIntent(R.id.orb, talk)

            val slots = intArrayOf(R.id.f1, R.id.f2, R.id.f3, R.id.f4)
            val favs = Apps.favorites(ctx, 4)
            for (i in slots.indices) {
                val f = favs.getOrNull(i)
                if (f == null) {
                    v.setViewVisibility(slots[i], View.GONE)
                    continue
                }
                val bmp = Apps.icon(ctx, f.pkg, 96)
                if (bmp != null) v.setImageViewBitmap(slots[i], bmp)
                v.setViewVisibility(slots[i], View.VISIBLE)
                val open = PendingIntent.getActivity(
                    ctx, 100 + i,
                    Intent(ctx, VoiceActivity::class.java)
                        .putExtra(VoiceActivity.EXTRA_OPEN, f.pkg)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    flags
                )
                v.setOnClickPendingIntent(slots[i], open)
            }
            return v
        }
    }
}
