package com.nova.assistant

import java.util.Calendar

object Timex {
    class Clock(val hour: Int, val minute: Int)

    /** Секунды из «через 1 час 20 минут», «на 5 минут», «через полчаса». 0 = не нашла. */
    fun duration(s: String): Int {
        if (s.contains("полчаса")) return 1800
        var total = 0
        for (m in Regex("(\\d+)\\s*(час\\p{L}*|мин\\p{L}*|сек\\p{L}*)").findAll(s)) {
            val n = m.groupValues[1].toIntOrNull() ?: 0
            val u = m.groupValues[2]
            total += when {
                u.startsWith("час") -> n * 3600
                u.startsWith("мин") -> n * 60
                else -> n
            }
        }
        if (total == 0 && Regex("(?:через|на)\\s+час(?=\\s|\\z)").containsMatchIn(s)) total = 3600
        return total
    }

    fun afterSeconds(sec: Int): Clock {
        val c = Calendar.getInstance()
        c.add(Calendar.SECOND, sec)
        return Clock(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    /** Время суток из «в 7:30», «на 7 30», «в 7 часов 15 минут», «в 7 утра». */
    fun clock(s: String): Clock? {
        var h = -1
        var m = 0
        val r1 = Regex("(\\d{1,2})\\s*:\\s*(\\d{2})").find(s)
        if (r1 != null) {
            h = r1.groupValues[1].toInt()
            m = r1.groupValues[2].toInt()
        } else {
            val r2 = Regex("(\\d{1,2})\\s*час\\p{L}*(?:\\s+(\\d{1,2})\\s*мин\\p{L}*)?").find(s)
            if (r2 != null) {
                h = r2.groupValues[1].toInt()
                m = r2.groupValues[2].toIntOrNull() ?: 0
            } else {
                val r3 = Regex("(?:в|на|к)\\s+(\\d{1,2})\\s+(\\d{2})(?!\\d)").find(s)
                if (r3 != null) {
                    h = r3.groupValues[1].toInt()
                    m = r3.groupValues[2].toInt()
                } else {
                    val r4 = Regex("(?:в|на|к)\\s+(\\d{1,2})(?=\\s|\\z)").find(s)
                    if (r4 != null) h = r4.groupValues[1].toInt()
                }
            }
        }
        if (h < 0 || h > 23 || m < 0 || m > 59) return null
        val morning = Regex("утр\\p{L}*").containsMatchIn(s)
        val evening = Regex("вечер\\p{L}*").containsMatchIn(s)
        val day = Regex("дн(?:я|ем)(?=\\s|\\z)").containsMatchIn(s)
        val night = Regex("ноч\\p{L}*").containsMatchIn(s)
        if (h < 12 && (evening || day)) h += 12
        if (h == 12 && (night || morning)) h = 0
        return Clock(h, m)
    }
}
