package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Toast

/**
 * Служба доступности Новы. Делает две вещи:
 * 1) показывает плавающий шар ассистента на рабочем столе;
 * 2) после команды «напиши…» выбирает чат и нажимает «Отправить» в нужном приложении.
 */
class AssistantService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AssistantService? = null
        private val SEND = setOf("отправить", "send", "надіслати", "отправить сообщение")
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var orb: OrbView? = null
    private var homePkg = ""
    private var curPkg = ""

    // текущая задача «написать сообщение»
    private var jobPkg = ""
    private var jobContact = ""
    private var jobUntil = 0L
    private var picked = false
    private var typed = false
    private var lastAct = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        homePkg = findHome()
        curPkg = rootInActiveWindow?.packageName?.toString() ?: ""
        refresh()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = e.packageName?.toString() ?: return
        if (p == "com.android.systemui" || p.contains("inputmethod") || p.contains("keyboard")) return
        curPkg = p
        refresh()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        main.removeCallbacksAndMessages(null)
        removeOrbNow()
        return super.onUnbind(intent)
    }

    // ---------------------------------------------------------------- шар

    private fun findHome(): String {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName ?: ""
    }

    /** Показать или спрятать шар в зависимости от настроек и текущего экрана. */
    fun refresh() {
        val onHome = curPkg.isNotEmpty() && curPkg == homePkg
        val want = Prefs.enabled(this) && curPkg != packageName &&
            (onHome || (Prefs.orbEverywhere(this) && curPkg.isNotEmpty()))
        if (want) showOrb() else hideOrb()
    }

    /** Вызывается после закрытия окон Новы: заново определяем, что на экране. */
    fun recheck() {
        main.postDelayed({
            val p = rootInActiveWindow?.packageName?.toString()
            if (p != null && p != "com.android.systemui") curPkg = p
            refresh()
        }, 500L)
    }

    private fun showOrb() {
        if (orb != null) return
        val w = wm ?: return
        val size = Ui.dp(this, 64)
        val dm = resources.displayMetrics
        val v = OrbView(this)
        val p = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        val sx = Prefs.orbX(this)
        val sy = Prefs.orbY(this)
        p.x = if (sx >= 0) sx else dm.widthPixels - size - Ui.dp(this, 8)
        p.y = if (sy >= 0) sy else (dm.heightPixels * 0.62f).toInt()
        v.setOnTouchListener(Drag(p))
        v.alpha = 0f
        v.scaleX = 0.3f
        v.scaleY = 0.3f
        try {
            w.addView(v, p)
        } catch (e: Exception) {
            return
        }
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420L)
            .setInterpolator(OvershootInterpolator(1.8f)).start()
        orb = v
    }

    private fun hideOrb() {
        val v = orb ?: return
        orb = null
        v.animate().alpha(0f).scaleX(0.3f).scaleY(0.3f).setDuration(200L).withEndAction {
            try {
                wm?.removeView(v)
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun removeOrbNow() {
        val v = orb ?: return
        orb = null
        try {
            wm?.removeView(v)
        } catch (e: Exception) {
        }
    }

    private fun openVoice() {
        val i = Intent(this, VoiceActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Разрешите Нове «Всплывающие окна в фоне» в настройках приложения",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private inner class Drag(val p: WindowManager.LayoutParams) : View.OnTouchListener {
        private var downX = 0f
        private var downY = 0f
        private var startX = 0
        private var startY = 0
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = p.x
                    startY = p.y
                    moved = false
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(100L).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val ox = (e.rawX - downX).toInt()
                    val oy = (e.rawY - downY).toInt()
                    val slop = Ui.dp(this@AssistantService, 8)
                    if (!moved && (Math.abs(ox) > slop || Math.abs(oy) > slop)) moved = true
                    if (moved) {
                        p.x = startX + ox
                        p.y = startY + oy
                        try {
                            wm?.updateViewLayout(v, p)
                        } catch (ex: Exception) {
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(260L)
                        .setInterpolator(OvershootInterpolator(2f)).start()
                    if (moved) {
                        snap(v, p)
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        openVoice()
                    }
                }
            }
            return true
        }
    }

    /** После перетаскивания шар плавно «прилипает» к ближайшему краю. */
    private fun snap(v: View, p: WindowManager.LayoutParams) {
        val dm = resources.displayMetrics
        val size = if (v.width > 0) v.width else Ui.dp(this, 64)
        val margin = Ui.dp(this, 8)
        val targetX = if (p.x + size / 2 < dm.widthPixels / 2) margin else dm.widthPixels - size - margin
        val minY = Ui.dp(this, 40)
        val maxY = dm.heightPixels - size - Ui.dp(this, 80)
        p.y = p.y.coerceIn(minY, maxY)
        val anim = ValueAnimator.ofInt(p.x, targetX)
        anim.duration = 320L
        anim.interpolator = DecelerateInterpolator(2f)
        anim.addUpdateListener {
            p.x = it.animatedValue as Int
            try {
                wm?.updateViewLayout(v, p)
            } catch (ex: Exception) {
            }
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                Prefs.setOrbPos(this@AssistantService, p.x, p.y)
            }
        })
        anim.start()
    }

    // ------------------------------------------------- отправка сообщений

    /** Запустить задачу: [contact] пусто — чат уже открыт, нужно только нажать «Отправить». */
    fun begin(pkg: String, contact: String) {
        jobPkg = pkg
        jobContact = contact
        jobUntil = System.currentTimeMillis() + 30000L
        picked = contact.isEmpty()
        typed = false
        lastAct = System.currentTimeMillis() + 900L
        main.removeCallbacks(poll)
        main.postDelayed(poll, 1000L)
    }

    private val poll = object : Runnable {
        override fun run() {
            if (jobPkg.isEmpty()) return
            if (System.currentTimeMillis() > jobUntil) {
                jobPkg = ""
                return
            }
            try {
                step()
            } catch (e: Exception) {
            }
            if (jobPkg.isNotEmpty()) main.postDelayed(this, 500L)
        }
    }

    private fun step() {
        val now = System.currentTimeMillis()
        if (now < lastAct) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != jobPkg) return
        val nodes = ArrayList<AccessibilityNodeInfo>()
        collect(root, nodes, 0)

        if (!picked) {
            val target = findContact(nodes, jobContact)
            if (target != null) {
                if (click(target)) {
                    picked = true
                    lastAct = now + 1000L
                }
                return
            }
            if (!typed) {
                val edit = nodes.firstOrNull { it.isEditable }
                if (edit != null) {
                    val b = Bundle()
                    b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, searchTerm(jobContact))
                    if (edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) {
                        typed = true
                        lastAct = now + 900L
                    }
                    return
                }
                val icon = nodes.firstOrNull {
                    val d = Text.norm(it.contentDescription?.toString() ?: "")
                    d == "поиск" || d == "search"
                }
                if (icon != null) {
                    click(icon)
                    lastAct = now + 700L
                }
            }
            return
        }

        val btn = findSend(nodes)
        if (btn != null && click(btn)) {
            jobPkg = ""
            Toast.makeText(this, "Нова: нажала «Отправить»", Toast.LENGTH_SHORT).show()
        }
    }

    /** «маме» → «мам», чтобы поиск нашёл «Мама». */
    private fun searchTerm(name: String): String {
        val first = name.trim().split(" ")[0]
        return if (first.length >= 4) first.substring(0, first.length - 1) else first
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (n == null || depth > 40 || out.size > 700) return
        out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    private fun findContact(nodes: List<AccessibilityNodeInfo>, name: String): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        for (n in nodes) {
            if (n.isEditable) continue
            val t = (n.text ?: n.contentDescription)?.toString() ?: continue
            if (t.length > 40) continue
            val s = Text.nameScore(name, t)
            if (s > bestScore) {
                bestScore = s
                best = n
            }
        }
        return best
    }

    private fun findSend(nodes: List<AccessibilityNodeInfo>): AccessibilityNodeInfo? {
        for (n in nodes) {
            if (!n.isVisibleToUser) continue
            val id = n.viewIdResourceName ?: ""
            val label = Text.norm((n.contentDescription ?: n.text)?.toString() ?: "")
            if (id.endsWith(":id/send") || SEND.contains(label)) return n
        }
        return null
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
            hops++
        }
        return tap(n)
    }

    private fun tap(n: AccessibilityNodeInfo): Boolean {
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path()
        path.moveTo(r.exactCenterX(), r.exactCenterY())
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 60L))
            .build()
        return dispatchGesture(g, null, null)
    }
}
