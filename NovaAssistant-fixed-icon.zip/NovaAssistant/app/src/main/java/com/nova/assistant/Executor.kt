package com.nova.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import org.json.JSONObject

/** Выполняет действия, которые решил сделать «мозг» (ИИ или разбор команд). */
object Executor {
    private val LAUNCH = setOf("open_app", "message", "photo")
    private var didLaunch = false

    class Result(val error: String?, val leaves: Boolean)

    fun run(ctx: Context, actions: List<JSONObject>): Result {
        didLaunch = false
        var err: String? = null
        var launched = false
        var skipped = false
        // сначала действия без открытия приложений (будильник, таймер), потом одно с открытием
        val sorted = actions.sortedBy { LAUNCH.contains(it.optString("type")) }
        for (a in sorted) {
            val type = a.optString("type")
            if (LAUNCH.contains(type)) {
                if (launched) {
                    skipped = true
                    continue
                }
                launched = true
            }
            val e = try {
                exec(ctx, a)
            } catch (ex: Exception) {
                "Ошибка: " + (ex.message ?: type)
            }
            if (e != null && err == null) err = e
        }
        if (err == null && skipped) err = "Выполнила только первое действие с открытием приложения"
        return Result(err, didLaunch)
    }

    private fun exec(ctx: Context, a: JSONObject): String? {
        return when (val type = a.optString("type")) {
            "open_app" -> open(ctx, a.optString("app"))
            "message" -> message(ctx, a)
            "alarm" -> alarm(ctx, a)
            "timer" -> timer(ctx, a)
            "photo" -> photo(ctx, a)
            "favorite" -> favorite(ctx, a.optString("app"))
            else -> "Не умею такое действие: " + type
        }
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return try {
            ctx.startActivity(i)
            didLaunch = true
            Prefs.countUse(ctx, pkg)
            AssistantWidget.refresh(ctx)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun open(ctx: Context, name: String): String? {
        if (name == "*favorite") {
            val f = Apps.favorites(ctx, 1).firstOrNull()
                ?: return "Пока нет любимых приложений. Скажите: «запомни ютуб как любимое»."
            return if (launch(ctx, f.pkg)) null else "Не получилось открыть " + f.label
        }
        val app = Apps.resolve(ctx, name)
            ?: return "Не нашла приложение «" + name + "». Привяжите его в настройках Новы."
        return if (launch(ctx, app.pkg)) null else "Не получилось открыть " + app.label
    }

    private fun message(ctx: Context, a: JSONObject): String? {
        val appName = a.optString("app").ifBlank { Prefs.defaultMessenger(ctx) }
        val to = a.optString("to").trim()
        val text = a.optString("text").trim()
        if (to.isEmpty()) return "Кому написать?"
        if (text.isEmpty()) return "Что написать?"
        val app = Apps.resolve(ctx, appName) ?: return "Не нашла приложение «" + appName + "»"
        val hit = Contacts.find(ctx, to)
        val service = AssistantService.instance
        var started = false

        // WhatsApp + номер из контактов: открываем чат сразу с готовым текстом
        if (Apps.WA.contains(app.pkg) && hit != null) {
            val num = Contacts.digits(ctx, hit.number)
            val uri = Uri.parse("https://wa.me/" + num + "?text=" + Uri.encode(text))
            val i = Intent(Intent.ACTION_VIEW, uri)
                .setPackage(app.pkg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(i)
                started = true
                service?.begin(app.pkg, "")
            } catch (e: Exception) {
                started = false
            }
        }
        // любое другое приложение: «Поделиться» → выбираем чат по имени → отправляем
        if (!started) {
            val who = hit?.name ?: to
            val i = Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, text)
                .setPackage(app.pkg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                ctx.startActivity(i)
            } catch (e: Exception) {
                return "«" + app.label + "» не принимает текст через «Поделиться». Откройте чат вручную."
            }
            service?.begin(app.pkg, who)
        }
        didLaunch = true
        Prefs.countUse(ctx, app.pkg)
        AssistantWidget.refresh(ctx)
        return if (service == null) {
            "Текст готов, но нажать «Отправить» я смогу, только если включена служба доступности Новы."
        } else null
    }

    private fun alarm(ctx: Context, a: JSONObject): String? {
        val h = a.optInt("hour", -1)
        val m = a.optInt("minute", 0)
        if (h !in 0..23 || m !in 0..59) return "Не поняла время будильника"
        val label = a.optString("label").ifBlank { "Нова" }
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            null
        } catch (e: Exception) {
            try {
                i.removeExtra(AlarmClock.EXTRA_SKIP_UI)
                ctx.startActivity(i)
                didLaunch = true
                null
            } catch (e2: Exception) {
                "Не получилось поставить будильник"
            }
        }
    }

    private fun timer(ctx: Context, a: JSONObject): String? {
        val sec = a.optInt("seconds", 0)
        if (sec !in 1..86400) return "Не поняла, на сколько таймер"
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label").ifBlank { "Нова" })
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            null
        } catch (e: Exception) {
            "Не получилось поставить таймер"
        }
    }

    private fun photo(ctx: Context, a: JSONObject): String? {
        val i = Intent(ctx, CaptureActivity::class.java)
            .putExtra("front", a.optBoolean("front", false))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        didLaunch = true
        return null
    }

    private fun favorite(ctx: Context, name: String): String? {
        val app = Apps.resolve(ctx, name) ?: return "Не нашла приложение «" + name + "»"
        Prefs.setPinned(ctx, app.pkg, true)
        AssistantWidget.refresh(ctx)
        return null
    }
}
