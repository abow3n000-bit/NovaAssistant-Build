package com.nova.assistant

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/** Анимированный «шар» ассистента: дышит, пульсирует от голоса, крутится при раздумьях. */
class OrbView(context: Context) : View(context) {

    enum class State { IDLE, LISTENING, THINKING, DONE }

    var state: State = State.IDLE
        set(value) {
            field = value
            invalidate()
        }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()
    private var glow: Shader? = null
    private var core: Shader? = null
    private var shine: Shader? = null
    private var phase = 0f
    private var level = 0f
    private var target = 0f

    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 5000L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            level += (target - level) * 0.18f
            invalidate()
        }
    }

    init {
        ring.style = Paint.Style.STROKE
        arc.style = Paint.Style.STROKE
        arc.strokeCap = Paint.Cap.ROUND
    }

    /** rms из SpeechRecognizer (примерно -2..10). */
    fun setLevel(rms: Float) {
        target = ((rms + 2f) / 12f).coerceIn(0f, 1f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) / 2f
        glow = RadialGradient(
            cx, cy, r,
            intArrayOf(Color.argb(150, 124, 77, 255), Color.argb(50, 0, 229, 255), Color.argb(0, 0, 0, 0)),
            floatArrayOf(0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        core = SweepGradient(cx, cy, intArrayOf(Ui.PURPLE, Ui.CYAN, Ui.PINK, Ui.PURPLE), null)
        shine = RadialGradient(
            cx - r * 0.16f, cy - r * 0.2f, r * 0.5f,
            intArrayOf(Color.argb(110, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            null, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val half = minOf(width, height) / 2f
        val t = phase * 2f * PI.toFloat()

        val breathe = when (state) {
            State.IDLE -> 0.03f * sin(t)
            State.LISTENING -> 0.04f + 0.16f * level
            State.THINKING -> 0.04f * sin(t * 4f)
            State.DONE -> 0f
        }
        val coreR = half * 0.5f * (1f + breathe)

        fill.shader = glow
        canvas.drawCircle(cx, cy, half, fill)

        if (state == State.LISTENING) {
            ring.strokeWidth = half * 0.03f
            for (i in 0..2) {
                val p = (phase * 3f + i / 3f) % 1f
                ring.color = Color.argb(((1f - p) * 100).toInt(), 0, 229, 255)
                canvas.drawCircle(cx, cy, coreR + (half - coreR) * p, ring)
            }
        }

        val spin = if (state == State.THINKING) 3f else 1f
        canvas.save()
        canvas.rotate(phase * 360f * spin, cx, cy)
        fill.shader = core
        canvas.drawCircle(cx, cy, coreR, fill)
        canvas.restore()

        fill.shader = shine
        canvas.drawCircle(cx, cy, coreR, fill)
        fill.shader = null

        if (state == State.THINKING) {
            arc.strokeWidth = half * 0.05f
            arc.color = Color.argb(220, 255, 255, 255)
            val rr = coreR + half * 0.12f
            oval.set(cx - rr, cy - rr, cx + rr, cy + rr)
            canvas.drawArc(oval, phase * 360f * 2f, 100f, false, arc)
        }
    }
}
