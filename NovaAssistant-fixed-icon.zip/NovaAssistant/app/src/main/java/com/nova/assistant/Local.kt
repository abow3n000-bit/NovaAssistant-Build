package com.nova.assistant

import android.content.Context

/** Разбор простых русских команд прямо на телефоне, без интернета и без ключа ИИ. */
object Local {
    private val IC = RegexOption.IGNORE_CASE
    private val MESS = listOf(
        "whatsapp", "ватсапп", "ватсап", "вотсапп", "вотсап", "вацап",
        "телеграмм", "телеграм", "telegram", "телега", "вайбер", "viber", "тг"
    )
    private const val VERB = "(?:напиши|написать|отправь|отправить|пошли|скинь|кинь|сообщи|черкни)"
    private const val TAIL = "(?=[\\s,.!?:]|\\z)"
    private const val LEAD = "^(?:что|сообщение|текст)\\s+"

    fun parse(ctx: Context, raw: String): Brain.Plan {
        val t = raw.trim().trim('.', '!', '?', ' ').trim()
        if (t.isEmpty()) return Brain.Plan("Я вас не расслышала", emptyList())

        message(ctx, t)?.let { return it }

        if (Regex("таймер", IC).containsMatchIn(t)) return timer(t)
        if (Regex("будильник|разбуди|подъем|подъём", IC).containsMatchIn(t)) return alarm(t)

        if (Regex("сфотограф|сфотк|сделай\\s+(?:фото|снимок|селфи|фотк|фотограф)|сними\\s+меня|селфи", IC).containsMatchIn(t)) {
            val front = Regex("селфи|себя|меня|фронтальн|передн", IC).containsMatchIn(t)
            return Brain.Plan(
                if (front) "Селфи через 3 секунды" else "Фото через 3 секунды",
                listOf(Brain.act("photo", "front" to front))
            )
        }

        val rf = Regex("^(?:запомни|добавь|закрепи|сохрани)\\s+(?:приложение\\s+)?(.+?)\\s+(?:как\\s+|в\\s+)?(?:любим\\p{L}*|избранн\\p{L}*)", IC)
        rf.find(t)?.let { m ->
            val name = m.groupValues[1].trim()
            return Brain.Plan("Запомнила: " + name + " — в любимых", listOf(Brain.act("favorite", "app" to name)))
        }

        val ro = Regex("^(?:пожалуйста\\s+)?(?:открой|открыть|запусти|запустить|включи|зайди\\s+в|зайди\\s+на|перейди\\s+в|покажи)\\s+(?:мне\\s+)?(?:приложение\\s+)?(.+)", IC)
        ro.find(t)?.let { m ->
            val name = m.groupValues[1].trim()
            val fav = Regex("^(?:мо[её]\\s+)?(?:любим\\p{L}*|избранн\\p{L}*)", IC).containsMatchIn(name)
            if (fav) {
                return Brain.Plan("Открываю любимое приложение", listOf(Brain.act("open_app", "app" to "*favorite")))
            }
            return Brain.Plan("Открываю " + name, listOf(Brain.act("open_app", "app" to name)))
        }

        return Brain.Plan(
            "Не поняла команду. Подключите ИИ в настройках — тогда пойму любые фразы. " +
                "Без него умею: «открой ютуб», «напиши маме в ватсап буду поздно», " +
                "«поставь будильник на 7:30», «таймер на 5 минут», «сфотографируй».",
            emptyList()
        )
    }

    private fun message(ctx: Context, t: String): Brain.Plan? {
        val extra = Prefs.bound(ctx)
            .filter { it.messenger && it.alias.isNotBlank() }
            .map { Regex.escape(it.alias.trim()) }
        val alt = (MESS.map { Regex.escape(it) } + extra).sortedByDescending { it.length }.joinToString("|")

        // «напиши маме в ватсап привет»
        val r1 = Regex("^" + VERB + "\\s+(?:сообщение\\s+)?(.+?)\\s+(?:в|во|через|по)\\s+(" + alt + ")" + TAIL + "[\\s,:]*(?:что\\s+|сообщение\\s+|текст\\s+)?(.*)", IC)
        r1.find(t)?.let { m ->
            return build(ctx, m.groupValues[2], m.groupValues[1], m.groupValues[3])
        }
        // «напиши в телеграм маме привет»
        val r2 = Regex("^" + VERB + "\\s+(?:сообщение\\s+)?(?:в|во|через)\\s+(" + alt + ")" + TAIL + "[\\s,:]*(.*)", IC)
        r2.find(t)?.let { m ->
            val rest = m.groupValues[2].trim()
            val sp = rest.indexOf(' ')
            val to = if (sp < 0) rest else rest.substring(0, sp)
            val body = if (sp < 0) "" else rest.substring(sp + 1).replace(Regex(LEAD, IC), "")
            return build(ctx, m.groupValues[1], to, body)
        }
        // «напиши маме привет» — мессенджер по умолчанию
        val r3 = Regex("^" + VERB + "\\s+(?:сообщение\\s+)?(?!в\\s|во\\s)(\\p{L}+)\\s+(.+)", IC)
        r3.find(t)?.let { m ->
            return build(ctx, "", m.groupValues[1], m.groupValues[2].replace(Regex(LEAD, IC), ""))
        }
        return null
    }

    private fun build(ctx: Context, appWord: String, to: String, text: String): Brain.Plan {
        val who = to.trim().trim(',', ':')
        val body = text.trim()
        if (who.isEmpty()) return Brain.Plan("Кому написать?", emptyList())
        if (body.isEmpty()) return Brain.Plan("Что написать для «" + who + "»?", emptyList())
        val app = if (appWord.isBlank()) Prefs.defaultMessenger(ctx) else appWord
        return Brain.Plan(
            "Пишу: " + who + " — «" + body + "»",
            listOf(Brain.act("message", "app" to app, "to" to who, "text" to body))
        )
    }

    private fun alarm(t: String): Brain.Plan {
        val s = Text.numberize(Text.light(t))
        val rel = if (s.contains("через")) Timex.duration(s) else 0
        val c = if (rel > 0) Timex.afterSeconds(rel) else Timex.clock(s)
        if (c == null) return Brain.Plan("На какое время поставить будильник?", emptyList())
        val hh = c.hour.toString().padStart(2, '0')
        val mm = c.minute.toString().padStart(2, '0')
        return Brain.Plan(
            "Будильник на " + hh + ":" + mm,
            listOf(Brain.act("alarm", "hour" to c.hour, "minute" to c.minute))
        )
    }

    private fun timer(t: String): Brain.Plan {
        val s = Text.numberize(Text.light(t))
        val sec = Timex.duration(s)
        if (sec <= 0) return Brain.Plan("На сколько поставить таймер?", emptyList())
        return Brain.Plan("Таймер на " + human(sec), listOf(Brain.act("timer", "seconds" to sec)))
    }

    private fun human(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add(h.toString() + " ч")
        if (m > 0) parts.add(m.toString() + " мин")
        if (s > 0 && h == 0) parts.add(s.toString() + " сек")
        return parts.joinToString(" ")
    }
}
