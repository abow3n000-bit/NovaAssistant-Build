package com.nova.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

object Ui {
    val PURPLE: Int = Color.rgb(124, 77, 255)
    val CYAN: Int = Color.rgb(0, 229, 255)
    val PINK: Int = Color.rgb(255, 64, 129)
    val TEXT2: Int = Color.rgb(154, 165, 192)

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun round(color: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.setColor(color)
        g.cornerRadius = radius
        if (strokeW > 0) g.setStroke(strokeW, stroke)
        return g
    }

    fun gradient(radius: Float): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(PURPLE, CYAN))
        g.cornerRadius = radius
        return g
    }

    /** Мягкое «нажатие» с пружинкой. */
    fun press(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(280)
                        .setInterpolator(OvershootInterpolator(2.2f)).start()
            }
            false
        }
    }

    /** Плавное появление снизу вверх. */
    fun rise(v: View, delay: Long) {
        v.alpha = 0f
        v.translationY = 40f
        v.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(450)
            .setInterpolator(DecelerateInterpolator(2f)).start()
    }
}
