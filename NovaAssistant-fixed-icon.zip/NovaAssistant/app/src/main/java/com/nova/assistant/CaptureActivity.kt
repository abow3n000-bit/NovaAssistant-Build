package com.nova.assistant

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaActionSound
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Камера Новы: обратный отсчёт 3-2-1, снимок и сохранение в Pictures/Nova. */
class CaptureActivity : ComponentActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var preview: PreviewView
    private lateinit var count: TextView
    private lateinit var status: TextView
    private lateinit var flash: View
    private var capture: ImageCapture? = null
    private var front = false

    private val askCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            startCamera()
        } else {
            Toast.makeText(this, "Нужен доступ к камере", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        front = intent.getBooleanExtra("front", false)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        preview = PreviewView(this)
        root.addView(preview, FrameLayout.LayoutParams(-1, -1))

        count = TextView(this)
        count.setTextColor(Color.WHITE)
        count.textSize = 120f
        count.gravity = Gravity.CENTER
        count.setShadowLayer(14f, 0f, 0f, Color.BLACK)
        root.addView(count, FrameLayout.LayoutParams(-1, -1))

        status = TextView(this)
        status.setTextColor(Color.WHITE)
        status.textSize = 18f
        status.gravity = Gravity.CENTER
        status.setShadowLayer(10f, 0f, 0f, Color.BLACK)
        val sl = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)
        sl.bottomMargin = Ui.dp(this, 60)
        root.addView(status, sl)

        flash = View(this)
        flash.setBackgroundColor(Color.WHITE)
        flash.alpha = 0f
        root.addView(flash, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            askCamera.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val pv = Preview.Builder().build()
                pv.setSurfaceProvider(preview.surfaceProvider)
                val cap = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                capture = cap
                val sel = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                provider.unbindAll()
                provider.bindToLifecycle(this, sel, pv, cap)
                status.text = if (front) "Селфи — улыбнитесь" else "Наведите камеру"
                countdown(3)
            } catch (e: Exception) {
                Toast.makeText(this, "Камера недоступна: " + (e.message ?: ""), Toast.LENGTH_LONG).show()
                finish()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun countdown(n: Int) {
        if (n <= 0) {
            shoot()
            return
        }
        count.text = n.toString()
        count.alpha = 1f
        count.scaleX = 1.7f
        count.scaleY = 1.7f
        count.animate().scaleX(1f).scaleY(1f).alpha(0.2f).setDuration(900L).start()
        ui.postDelayed({ countdown(n - 1) }, 1000L)
    }

    private fun shoot() {
        count.text = ""
        val cap = capture ?: return
        val name = "Nova_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Nova")
        val opts = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        MediaActionSound().play(MediaActionSound.SHUTTER_CLICK)
        flash.alpha = 0.9f
        flash.animate().alpha(0f).setDuration(380L).start()
        cap.takePicture(opts, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                status.text = "Фото сохранено в Pictures/Nova ✓"
                Speaker.say(this@CaptureActivity, "Готово")
                ui.postDelayed({ finish() }, 1500L)
            }

            override fun onError(exception: ImageCaptureException) {
                Toast.makeText(this@CaptureActivity, "Не удалось сохранить фото", Toast.LENGTH_LONG).show()
                finish()
            }
        })
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
