package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Окно ассистента: шар, распознавание речи, поле для текста. Выезжает снизу. */
class VoiceActivity : Activity() {

    companion object {
        const val EXTRA_OPEN = "open_pkg"
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var scrim: View
    private lateinit var sheet: LinearLayout
    private lateinit var orb: OrbView
    private lateinit var caption: TextView
    private lateinit var reply: TextView
    private lateinit var input: EditText
    private var rec: SpeechRecognizer? = null
    private var busy = false
    private var closing = false
    private var leaving = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // быстрый запуск любимого приложения из виджета
        val open = intent.getStringExtra(EXTRA_OPEN)
        if (open != null) {
            Executor.launch(this, open)
            finish()
            overridePendingTransition(0, 0)
            return
        }
        if (!Prefs.enabled(this)) {
            Toast.makeText(this, "Нова выключена — включите её в настройках", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        buildUi()
        enter()
        if (hasMic()) ui.postDelayed({ listen() }, 480L) else requestMic()
    }

    private fun buildUi() {
        val root = FrameLayout(this)

        scrim = View(this)
        scrim.setBackgroundColor(Color.parseColor("#99000000"))
        scrim.setOnClickListener { close() }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        sheet = LinearLayout(this)
        sheet.orientation = LinearLayout.VERTICAL
        sheet.gravity = Gravity.CENTER_HORIZONTAL
        val r = Ui.dp(this, 28).toFloat()
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#F2121426"))
        bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        sheet.background = bg
        sheet.setPadding(Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 20))
        sheet.isClickable = true

        val handle = View(this)
        handle.background = Ui.round(Color.parseColor("#44FFFFFF"), Ui.dp(this, 3).toFloat())
        sheet.addView(handle, LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 5)))

        orb = OrbView(this)
        orb.setOnClickListener { if (!busy) listen() }
        val ol = LinearLayout.LayoutParams(Ui.dp(this, 150), Ui.dp(this, 150))
        ol.topMargin = Ui.dp(this, 8)
        sheet.addView(orb, ol)

        caption = TextView(this)
        caption.setTextColor(Color.WHITE)
        caption.textSize = 20f
        caption.gravity = Gravity.CENTER
        caption.text = "Слушаю…"
        sheet.addView(caption, LinearLayout.LayoutParams(-1, -2))

        reply = TextView(this)
        reply.setTextColor(Color.parseColor("#7DE7FF"))
        reply.textSize = 15f
        reply.gravity = Gravity.CENTER
        val rl = LinearLayout.LayoutParams(-1, -2)
        rl.topMargin = Ui.dp(this, 8)
        sheet.addView(reply, rl)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        input = EditText(this)
        input.hint = "Или напишите команду…"
        input.setHintTextColor(Ui.TEXT2)
        input.setTextColor(Color.WHITE)
        input.textSize = 16f
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.maxLines = 3
        input.background = Ui.round(Color.parseColor("#1FFFFFFF"), Ui.dp(this, 22).toFloat())
        input.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10))
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submit()
                true
            } else {
                false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))

        val send = TextView(this)
        send.text = "➤"
        send.setTextColor(Color.WHITE)
        send.textSize = 20f
        send.gravity = Gravity.CENTER
        send.background = Ui.gradient(Ui.dp(this, 22).toFloat())
        send.setOnClickListener { submit() }
        Ui.press(send)
        val sl = LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44))
        sl.leftMargin = Ui.dp(this, 8)
        row.addView(send, sl)

        val rowLp = LinearLayout.LayoutParams(-1, -2)
        rowLp.topMargin = Ui.dp(this, 14)
        sheet.addView(row, rowLp)

        root.addView(sheet, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        sheet.translationY = 4000f
    }

    private fun enter() {
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(260L).start()
        sheet.post {
            sheet.translationY = sheet.height.toFloat()
            sheet.animate().translationY(0f).setDuration(420L)
                .setInterpolator(DecelerateInterpolator(2.2f)).start()
        }
    }

    private fun close() {
        if (closing) return
        closing = true
        stopRec()
        scrim.animate().alpha(0f).setDuration(220L).start()
        sheet.animate().translationY(sheet.height.toFloat()).setDuration(260L)
            .setInterpolator(DecelerateInterpolator()).withEndAction {
                finish()
                overridePendingTransition(0, 0)
            }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        close()
    }

    // ---------------------------------------------------------------- голос

    private fun hasMic(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestMic() {
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                listen()
            } else {
                caption.text = "Без микрофона можно писать команды текстом"
            }
        }
    }

    private fun listen() {
        if (busy || closing) return
        if (!hasMic()) {
            requestMic()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            caption.text = "Распознавание речи недоступно — напишите команду"
            return
        }
        stopRec()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                orb.setLevel(rmsdB)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                onRecError(error)
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
                if (t.isNullOrEmpty()) {
                    onRecError(SpeechRecognizer.ERROR_NO_MATCH)
                } else {
                    ui.post { stopRec() }
                    process(t)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrEmpty()) caption.text = t
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val si = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        si.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        si.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        si.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        si.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        caption.text = "Слушаю…"
        reply.text = ""
        orb.state = OrbView.State.LISTENING
        r.startListening(si)
    }

    private fun onRecError(code: Int) {
        if (closing || busy) return
        orb.state = OrbView.State.IDLE
        when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                caption.text = "Не расслышала. Нажмите на шар и повторите"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> requestMic()
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                caption.text = "Нет сети для распознавания. Напишите команду"
            SpeechRecognizer.ERROR_CLIENT -> {}
            else -> caption.text = "Не получилось услышать (код " + code + "). Напишите команду"
        }
    }

    private fun stopRec() {
        val r = rec ?: return
        rec = null
        try {
            r.cancel()
            r.destroy()
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------- команды

    private fun submit() {
        val t = input.text.toString().trim()
        if (t.isEmpty() || busy) return
        input.setText("")
        stopRec()
        process(t)
    }

    private fun process(cmd: String) {
        if (busy) return
        busy = true
        caption.text = cmd
        reply.text = ""
        orb.state = OrbView.State.THINKING
        val app = applicationContext
        Thread {
            val plan = try {
                Brain.decide(app, cmd)
            } catch (e: Exception) {
                Brain.Plan("Ошибка: " + (e.message ?: "неизвестная"), emptyList())
            }
            ui.post { finishPlan(plan) }
        }.start()
    }

    private fun finishPlan(plan: Brain.Plan) {
        busy = false
        if (closing || isFinishing || isDestroyed) return
        val res = Executor.run(this, plan.actions)
        val shown = (res.error ?: plan.say).ifBlank { "Готово" }
        orb.state = if (res.error == null) OrbView.State.DONE else OrbView.State.IDLE
        reply.text = shown
        Speaker.say(this, shown)
        if (res.leaves) {
            leaving = true
            ui.postDelayed({ finish() }, 2500L)
        } else {
            ui.postDelayed({ if (!closing) orb.state = OrbView.State.IDLE }, 1800L)
        }
    }

    override fun onStop() {
        super.onStop()
        if (leaving) finish()
    }

    override fun onDestroy() {
        stopRec()
        ui.removeCallbacksAndMessages(null)
        AssistantService.instance?.recheck()
        super.onDestroy()
    }
}
