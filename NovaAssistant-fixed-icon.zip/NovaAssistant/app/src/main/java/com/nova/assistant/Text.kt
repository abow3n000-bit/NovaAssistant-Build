package com.nova.assistant

object Text {
    /** Нижний регистр, ё→е, без знаков препинания. */
    fun norm(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s.lowercase()) {
            val c = if (ch == 'ё') 'е' else ch
            if (c.isLetterOrDigit()) sb.append(c) else sb.append(' ')
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /** Как norm, но двоеточие остаётся (для времени 7:30). */
    fun light(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s.lowercase()) {
            val c = if (ch == 'ё') 'е' else ch
            if (c.isLetterOrDigit() || c == ':') sb.append(c) else sb.append(' ')
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    private fun common(a: String, b: String): Int {
        var i = 0
        val n = minOf(a.length, b.length)
        while (i < n && a[i] == b[i]) i++
        return i
    }

    /** Похожесть запроса на имя с учётом падежей: «маме» ≈ «Мама». 0 = не подходит. */
    fun nameScore(query: String, name: String): Int {
        val qs = norm(query).split(" ").filter { it.isNotEmpty() }
        val ns = norm(name).split(" ").filter { it.isNotEmpty() }
        if (qs.isEmpty() || ns.isEmpty()) return 0
        var total = 0
        for (q in qs) {
            var best = 0
            for (n in ns) {
                val cp = common(q, n)
                val shorter = minOf(q.length, n.length)
                if (cp >= 2 && cp >= shorter - 2) {
                    val sc = cp * 10 - Math.abs(q.length - n.length)
                    if (sc > best) best = sc
                }
            }
            if (best == 0) return 0
            total += best
        }
        return total
    }

    private val UNITS: Map<String, Int> = mapOf(
        "ноль" to 0, "нуль" to 0, "один" to 1, "одна" to 1, "одну" to 1, "два" to 2, "две" to 2,
        "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8,
        "девять" to 9, "десять" to 10, "одиннадцать" to 11, "двенадцать" to 12,
        "тринадцать" to 13, "четырнадцать" to 14, "пятнадцать" to 15, "шестнадцать" to 16,
        "семнадцать" to 17, "восемнадцать" to 18, "девятнадцать" to 19
    )
    private val TENS: Map<String, Int> = mapOf(
        "двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50
    )

    /** «семь тридцать» → «7 30». Применять только к времени, не к тексту сообщений. */
    fun numberize(s: String): String {
        val words = s.split(" ")
        val out = ArrayList<String>()
        var i = 0
        while (i < words.size) {
            val w = words[i]
            val t = TENS[w]
            if (t != null) {
                val nxt = if (i + 1 < words.size) UNITS[words[i + 1]] else null
                if (nxt != null && nxt in 1..9) {
                    out.add((t + nxt).toString())
                    i += 2
                    continue
                }
                out.add(t.toString())
                i++
                continue
            }
            val u = UNITS[w]
            out.add(if (u != null) u.toString() else w)
            i++
        }
        return out.joinToString(" ")
    }
}
