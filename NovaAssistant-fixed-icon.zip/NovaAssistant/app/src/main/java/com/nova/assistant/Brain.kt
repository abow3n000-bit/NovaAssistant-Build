package com.nova.assistant

import android.content.Context
import org.json.JSONObject

object Brain {
    class Plan(val say: String, val actions: List<JSONObject>)

    fun act(type: String, vararg kv: Pair<String, Any>): JSONObject {
        val o = JSONObject().put("type", type)
        for ((k, v) in kv) o.put(k, v)
        return o
    }

    /** С ключом ИИ — понимает любые фразы; без ключа — разбор простых команд на телефоне. */
    fun decide(ctx: Context, text: String): Plan {
        if (Prefs.llmReady(ctx)) {
            try {
                return Llm.plan(ctx, text)
            } catch (e: Exception) {
                val local = Local.parse(ctx, text)
                if (local.actions.isNotEmpty()) return local
                return Plan("ИИ не ответил: " + (e.message ?: "ошибка сети"), emptyList())
            }
        }
        return Local.parse(ctx, text)
    }
}
