package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Главный экран Новы: включение, доступы, приложения, ИИ. */
class MainActivity : Activity() {

    private lateinit var content: LinearLayout
    private lateinit var orb: OrbView
    private lateinit var statusA11y: TextView
    private lateinit var statusPerm: TextView
    private lateinit var favText: TextView
    private lateinit var cc: EditText
    private lateinit var base: EditText
    private lateinit var key: EditText
    private lateinit var model: EditText
    private var cardIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#0B0D17"))
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(Ui.dp(this, 16), Ui.dp(this, 40), Ui.dp(this, 16), Ui.dp(this, 40))
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        setContentView(scroll)
        build()
    }

    // ------------------------------------------------------------ помощники

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Ui.round(
            Color.parseColor("#161A2E"), Ui.dp(this, 20).toFloat(), Color.parseColor("#22FFFFFF"), 1
        )
        c.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 16))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = Ui.dp(this, 14)
        content.addView(c, lp)
        Ui.rise(c, 120L + 70L * cardIndex)
        cardIndex++
        return c
    }

    private fun label(parent: LinearLayout, text: String, size: Float, color: Int, bold: Boolean, top: Int): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = Ui.dp(this, top)
        parent.addView(t, lp)
        return t
    }

    private fun button(parent: LinearLayout, text: String, filled: Boolean, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = text
        b.gravity = Gravity.CENTER
        b.textSize = 15f
        b.setTextColor(Color.WHITE)
        b.setTypeface(null, Typeface.BOLD)
        val r = Ui.dp(this, 14).toFloat()
        b.background = if (filled) Ui.gradient(r) else Ui.round(Color.parseColor("#26FFFFFF"), r)
        b.setPadding(Ui.dp(this, 16), Ui.dp(this, 13), Ui.dp(this, 16), Ui.dp(this, 13))
        b.setOnClickListener { onClick() }
        Ui.press(b)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = Ui.dp(this, 10)
        parent.addView(b, lp)
        return b
    }

    private fun toggle(parent: LinearLayout, text: String, on: Boolean, onChange: (Boolean) -> Unit) {
        val s = Switch(this)
        s.text = text
        s.setTextColor(Color.WHITE)
        s.textSize = 15f
        s.isChecked = on
        s.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = Ui.dp(this, 10)
        parent.addView(s, lp)
    }

    private fun field(parent: LinearLayout, hint: String, value: String, type: Int): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Ui.TEXT2)
        e.textSize = 14f
        e.setSingleLine(true)
        e.inputType = type
        e.background = Ui.round(Color.parseColor("#1FFFFFFF"), Ui.dp(this, 12).toFloat())
        e.setPadding(Ui.dp(this, 14), Ui.dp(this, 11), Ui.dp(this, 14), Ui.dp(this, 11))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = Ui.dp(this, 10)
        parent.addView(e, lp)
        return e
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    // ---------------------------------------------------------------- экран

    private fun build() {
        val white = Color.WHITE

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        orb = OrbView(this)
        head.addView(orb, LinearLayout.LayoutParams(Ui.dp(this, 96), Ui.dp(this, 96)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        label(titles, "Нова", 32f, white, true, 0)
        label(titles, "ИИ-ассистент для рабочего экрана", 14f, Ui.TEXT2, false, 2)
        val tl = LinearLayout.LayoutParams(0, -2, 1f)
        tl.leftMargin = Ui.dp(this, 14)
        head.addView(titles, tl)
        content.addView(head)
        Ui.rise(head, 0L)

        button(content, "🎙  Говорить с Новой", true) {
            startActivity(Intent(this, VoiceActivity::class.java))
        }

        // --- включение
        val c1 = card()
        label(c1, "Включение", 18f, white, true, 0)
        toggle(c1, "Ассистент включён", Prefs.enabled(this)) { on ->
            Prefs.setEnabled(this, on)
            AssistantService.instance?.refresh()
        }
        toggle(c1, "Шар поверх всех приложений (по умолчанию — только на рабочем столе)", Prefs.orbEverywhere(this)) { on ->
            Prefs.setOrbEverywhere(this, on)
            AssistantService.instance?.refresh()
        }
        toggle(c1, "Озвучивать ответы", Prefs.speak(this)) { on ->
            Prefs.setSpeak(this, on)
        }

        // --- доступы
        val c2 = card()
        label(c2, "Доступы", 18f, white, true, 0)
        statusA11y = label(c2, "", 14f, Ui.TEXT2, false, 8)
        button(c2, "Включить службу доступности", false) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        statusPerm = label(c2, "", 14f, Ui.TEXT2, false, 14)
        button(c2, "Выдать разрешения", false) {
            requestPermissions(
                arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA,
                    Manifest.permission.READ_CONTACTS
                ), 3
            )
        }
        button(c2, "Настройки приложения (автозапуск, всплывающие окна)", false) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))
            )
        }

        // --- приложения
        val c3 = card()
        label(c3, "Приложения", 18f, white, true, 0)
        favText = label(c3, "", 14f, Ui.TEXT2, false, 8)
        label(c3, "Виджет: удерживайте пустое место на рабочем столе → Виджеты → Нова.", 13f, Ui.TEXT2, false, 8)
        button(c3, "Привязать и закрепить приложения", true) {
            startActivity(Intent(this, AppsActivity::class.java))
        }

        // --- сообщения
        val c4 = card()
        label(c4, "Сообщения", 18f, white, true, 0)
        label(c4, "Куда писать, если вы не назвали приложение:", 13f, Ui.TEXT2, false, 8)
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        val wa = chip("WhatsApp")
        val tg = chip("Telegram")
        val radius = Ui.dp(this, 14).toFloat()
        fun paintChips() {
            val cur = Prefs.defaultMessenger(this)
            wa.background = if (cur == "whatsapp") Ui.gradient(radius) else Ui.round(Color.parseColor("#26FFFFFF"), radius)
            tg.background = if (cur == "telegram") Ui.gradient(radius) else Ui.round(Color.parseColor("#26FFFFFF"), radius)
        }
        wa.setOnClickListener {
            Prefs.setDefaultMessenger(this, "whatsapp")
            paintChips()
        }
        tg.setOnClickListener {
            Prefs.setDefaultMessenger(this, "telegram")
            paintChips()
        }
        val l1 = LinearLayout.LayoutParams(0, -2, 1f)
        l1.rightMargin = Ui.dp(this, 6)
        val l2 = LinearLayout.LayoutParams(0, -2, 1f)
        l2.leftMargin = Ui.dp(this, 6)
        chips.addView(wa, l1)
        chips.addView(tg, l2)
        val cl = LinearLayout.LayoutParams(-1, -2)
        cl.topMargin = Ui.dp(this, 10)
        c4.addView(chips, cl)
        paintChips()
        cc = field(c4, "Код страны для номеров (7 — Россия)", Prefs.countryCode(this), InputType.TYPE_CLASS_NUMBER)
        button(c4, "Сохранить код страны", false) {
            Prefs.setCountryCode(this, cc.text.toString())
            toast("Сохранено")
        }

        // --- ИИ
        val c5 = card()
        label(c5, "ИИ-мозг", 18f, white, true, 0)
        label(
            c5,
            "Без ключа Нова понимает простые команды. С ключом — любые фразы, вопросы и сложные просьбы. " +
                "Ключ хранится только на этом телефоне и отправляется лишь тому сервису, адрес которого вы укажете. " +
                "Подходит Anthropic (api.anthropic.com) и любой OpenAI-совместимый сервис.",
            13f, Ui.TEXT2, false, 8
        )
        base = field(c5, "Адрес, например https://api.anthropic.com", Prefs.llmBase(this),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        key = field(c5, "API-ключ", Prefs.llmKey(this),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        model = field(c5, "Название модели", Prefs.llmModel(this), InputType.TYPE_CLASS_TEXT)
        button(c5, "Сохранить и проверить", true) { saveLlm() }

        // --- примеры
        val c6 = card()
        label(c6, "Что можно сказать", 18f, white, true, 0)
        label(
            c6,
            "• «Открой ютуб»\n" +
                "• «Напиши маме в ватсап, что буду поздно»\n" +
                "• «Напиши Саше в телеграм привет»\n" +
                "• «Поставь будильник на 7:30»\n" +
                "• «Таймер на 5 минут»\n" +
                "• «Сфотографируй» или «сделай селфи»\n" +
                "• «Запомни ютуб как любимое» / «открой любимое»",
            14f, Ui.TEXT2, false, 8
        )
    }

    private fun chip(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.gravity = Gravity.CENTER
        t.textSize = 15f
        t.setTextColor(Color.WHITE)
        t.setTypeface(null, Typeface.BOLD)
        t.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12))
        Ui.press(t)
        return t
    }

    private fun saveLlm() {
        Prefs.setLlm(this, base.text.toString(), key.text.toString(), model.text.toString())
        if (!Prefs.llmReady(this)) {
            toast("Заполните адрес, ключ и модель — или оставьте пустыми, тогда работают простые команды")
            return
        }
        toast("Проверяю…")
        val app = applicationContext
        Thread {
            val res = try {
                val say = Llm.plan(app, "Скажи «привет» одним словом").say
                "ИИ подключён" + (if (say.isNotBlank()) ": " + say else "")
            } catch (e: Exception) {
                "Ошибка: " + (e.message ?: "нет ответа")
            }
            runOnUiThread { toast(res) }
        }.start()
    }

    // ------------------------------------------------------------- статусы

    private fun has(p: String): Boolean = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun a11yOn(): Boolean {
        if (AssistantService.instance != null) return true
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains(packageName + "/")
    }

    private fun yn(b: Boolean): String = if (b) "да" else "нет"

    private fun refreshStatus() {
        val on = a11yOn()
        statusA11y.text = if (on) {
            "● Служба доступности включена"
        } else {
            "○ Служба доступности выключена — без неё нет шара на рабочем столе и автоотправки сообщений"
        }
        statusA11y.setTextColor(Color.parseColor(if (on) "#69F0AE" else "#FF8A80"))
        statusPerm.text = "Микрофон: " + yn(has(Manifest.permission.RECORD_AUDIO)) +
            "  ·  Камера: " + yn(has(Manifest.permission.CAMERA)) +
            "  ·  Контакты: " + yn(has(Manifest.permission.READ_CONTACTS))
        val f = Apps.favorites(this, 6)
        favText.text = if (f.isEmpty()) {
            "Любимые появятся сами — по тому, что вы открываете чаще всего. Можно закрепить вручную."
        } else {
            "Любимые: " + f.joinToString(", ") { it.label }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        AssistantService.instance?.recheck()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refreshStatus()
    }
}
