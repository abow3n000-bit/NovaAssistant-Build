package com.nova.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Озвучка ответов. Живёт на уровне приложения, поэтому не обрывается при закрытии окна. */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null

    fun say(ctx: Context, text: String) {
        if (text.isBlank() || !Prefs.speak(ctx)) return
        if (tts == null) {
            tts = TextToSpeech(ctx.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.setLanguage(Locale("ru", "RU"))
                    ready = true
                    val p = pending
                    pending = null
                    if (p != null) tts?.speak(p, TextToSpeech.QUEUE_FLUSH, null, "nova")
                }
            }
        }
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova") else pending = text
    }

    fun stop() {
        tts?.stop()
    }
}
