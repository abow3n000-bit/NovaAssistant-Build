package com.nova.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract

object Contacts {
    class Hit(val name: String, val number: String)

    fun granted(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun find(ctx: Context, query: String): Hit? {
        if (query.isBlank() || !granted(ctx)) return null
        val cur = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        ) ?: return null
        var best: Hit? = null
        var bestScore = 0
        cur.use {
            while (it.moveToNext()) {
                val name = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                val s = Text.nameScore(query, name)
                if (s > bestScore) {
                    bestScore = s
                    best = Hit(name, num)
                }
            }
        }
        return best
    }

    /** Номер → только цифры, с кодом страны (для wa.me). */
    fun digits(ctx: Context, raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (d.length == 11 && d.startsWith("8")) {
            d = "7" + d.substring(1)
        } else if (d.length == 10) {
            d = Prefs.countryCode(ctx) + d
        }
        return d
    }
}
